from flask import Flask, request, redirect, url_for, session
import socket
import subprocess
import re
from datetime import datetime

app = Flask(__name__)
app.secret_key = "test_key"

ADMIN_PASSWORD = "admin123"

connected_devices = {}

def get_mac_from_arp(ip):
    try:
        output = subprocess.check_output("arp -a", shell=True).decode()
        pattern = rf"{ip}\s+([-\w]+)\s"
        match = re.search(pattern, output)
        if match:
            return match.group(1)
    except:
        pass
    return "Nieznany"

def detect_os(user_agent):
    ua = user_agent.lower()
    if "windows" in ua:
        return "Windows"
    elif "android" in ua:
        return "Android"
    elif "iphone" in ua:
        return "iOS"
    elif "mac" in ua:
        return "MacOS"
    elif "linux" in ua:
        return "Linux"
    else:
        return "Nieznany"

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        password = request.form.get("password")

        # Każde hasło akceptowane
        if password == ADMIN_PASSWORD:
            session["admin"] = True
            return redirect(url_for("admin_panel"))
        else:
            session["user"] = True
            session["password_used"] = password
            return redirect(url_for("user_panel"))

    return """
        <h2>Logowanie</h2>
        <form method="post">
            Wpisz dowolne hasło:<br><br>
            <input type="text" name="password">
            <input type="submit" value="Wejdź">
        </form>
    """

@app.route("/user")
def user_panel():
    if not session.get("user"):
        return redirect(url_for("login"))

    client_ip = request.remote_addr
    user_agent = request.headers.get("User-Agent")
    os_name = detect_os(user_agent)
    mac = get_mac_from_arp(client_ip)

    connected_devices[client_ip] = {
        "mac": mac,
        "os": os_name,
        "password": session.get("password_used"),
        "last_seen": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }

    data = connected_devices[client_ip]

    return f"""
        <h1>Twoje dane</h1>
        <p><b>IP:</b> {client_ip}</p>
        <p><b>MAC:</b> {data['mac']}</p>
        <p><b>System:</b> {data['os']}</p>
        <p><b>Hasło które wpisałeś:</b> {data['password']}</p>
        <p><b>Ostatnie wejście:</b> {data['last_seen']}</p>
        <br>
        <a href="/">Wyloguj</a>
    """

@app.route("/admin")
def admin_panel():
    if not session.get("admin"):
        return redirect(url_for("login"))

    html = "<h1>Panel Administratora</h1><table border=1>"
    html += "<tr><th>IP</th><th>MAC</th><th>System</th><th>Hasło</th><th>Ostatnio widziane</th></tr>"

    for ip, data in connected_devices.items():
        html += f"<tr><td>{ip}</td><td>{data['mac']}</td><td>{data['os']}</td><td>{data['password']}</td><td>{data['last_seen']}</td></tr>"

    html += "</table><br><a href='/'>Wyloguj</a>"

    return html

if __name__ == "__main__":
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))
    print(f"Serwer działa na: http://{s.getsockname()[0]}:5000")
    s.close()

    # UWAGA: to jest zwykły HTTP (brak SSL)
    app.run(host="0.0.0.0", port=5000)